<?php

  require_once('../Archive/Tar.php');

  $archive = new Archive_Tar('exploit.tar');
  $archive->extract();
